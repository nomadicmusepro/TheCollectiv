import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { MarqueeBar } from "@/components/marquee-bar"
import { FeaturedProjects } from "@/components/featured-projects"
import { ServicesSection } from "@/components/services-section"
import { CreativesSection } from "@/components/creatives-section"
import { CollaborateCta } from "@/components/collaborate-cta"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main>
      <Navbar />
      <HeroSection />
      <MarqueeBar />
      <FeaturedProjects />
      <ServicesSection />
      <CreativesSection />
      <CollaborateCta />
      <Footer />
    </main>
  )
}
