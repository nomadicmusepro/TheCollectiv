"use client"

import { useState } from "react"
import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Heart } from "lucide-react"

const projects = [
  {
    id: 1,
    title: "Meridian Brand Identity",
    description: "A complete brand overhaul for a sustainable fashion label",
    image: "/images/project-1.jpg",
    creator: "Amara Okafor",
    avatar: "/images/avatar-1.jpg",
    tags: ["Branding", "Design", "Strategy"],
    likes: 234,
  },
  {
    id: 2,
    title: "Voices of the Coast",
    description: "A short film exploring coastal communities and their untold stories",
    image: "/images/project-2.jpg",
    creator: "Valentina Reyes",
    avatar: "/images/avatar-3.jpg",
    tags: ["Film", "Documentary", "Directing"],
    likes: 189,
  },
  {
    id: 3,
    title: "Studio Reforma Interiors",
    description: "Reimagining living spaces with earthy textures and natural materials",
    image: "/images/project-3.jpg",
    creator: "Priya Nair",
    avatar: "/images/avatar-2.jpg",
    tags: ["Interior Design", "Architecture"],
    likes: 312,
  },
  {
    id: 4,
    title: "Watercolor Portfolio",
    description: "A curated collection of watercolor explorations and mixed media art",
    image: "/images/project-4.jpg",
    creator: "Marcus Tate",
    avatar: "/images/avatar-1.jpg",
    tags: ["Illustration", "Fine Art", "Mixed Media"],
    likes: 178,
  },
]

export function FeaturedProjects() {
  const [likedProjects, setLikedProjects] = useState<Set<number>>(new Set())

  const toggleLike = (id: number) => {
    setLikedProjects((prev) => {
      const next = new Set(prev)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }

  return (
    <section id="projects" className="py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="flex items-end justify-between mb-12">
          <div>
            <p className="text-sm font-medium tracking-widest uppercase text-primary mb-3">
              Selected Work
            </p>
            <h2 className="text-3xl md:text-4xl font-serif italic text-foreground text-balance">
              Featured Projects
            </h2>
          </div>
          <button className="hidden md:flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors">
            View all projects
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {projects.map((project) => (
            <article
              key={project.id}
              className="group cursor-pointer"
            >
              <div className="relative aspect-[4/5] rounded-lg overflow-hidden mb-4 bg-muted">
                <Image
                  src={project.image}
                  alt={project.title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    toggleLike(project.id)
                  }}
                  className="absolute top-3 right-3 p-2 rounded-full bg-background/80 backdrop-blur-sm hover:bg-background transition-colors"
                  aria-label={likedProjects.has(project.id) ? "Unlike project" : "Like project"}
                >
                  <Heart
                    className={`h-4 w-4 transition-colors ${
                      likedProjects.has(project.id)
                        ? "fill-accent text-accent"
                        : "text-muted-foreground"
                    }`}
                  />
                </button>
              </div>

              <div className="flex flex-col gap-2">
                <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {project.tags.map((tag) => (
                    <Badge
                      key={tag}
                      variant="secondary"
                      className="text-xs font-normal"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <Image
                    src={project.avatar}
                    alt={project.creator}
                    width={24}
                    height={24}
                    className="rounded-full object-cover h-6 w-6"
                  />
                  <span className="text-xs text-muted-foreground">
                    {project.creator}
                  </span>
                  <span className="ml-auto text-xs text-muted-foreground flex items-center gap-1">
                    <Heart className="h-3 w-3" />
                    {likedProjects.has(project.id)
                      ? project.likes + 1
                      : project.likes}
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>

        <button className="md:hidden flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors mt-8 mx-auto">
          View all projects
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </section>
  )
}
