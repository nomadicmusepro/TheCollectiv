"use client"

const disciplines = [
  "Branding",
  "Storytelling",
  "Photography",
  "Film",
  "Illustration",
  "Product Design",
  "Architecture",
  "Music Production",
  "Creative Direction",
  "UX Design",
  "Copywriting",
  "Animation",
]

export function MarqueeBar() {
  return (
    <div className="overflow-hidden bg-primary py-3">
      <div className="flex animate-marquee whitespace-nowrap">
        {[...disciplines, ...disciplines, ...disciplines].map((item, index) => (
          <span
            key={`${item}-${index}`}
            className="mx-6 text-sm font-medium tracking-wide uppercase text-primary-foreground"
          >
            {item} {"•••"}
          </span>
        ))}
      </div>
    </div>
  )
}
