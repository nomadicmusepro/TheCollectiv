"use client"

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

const services = [
  {
    title: "Creative Matchmaking",
    description:
      "We pair creatives based on complementary skills, shared values, and project goals. Whether you need a co-founder, a collaborator, or a fresh perspective — we help you find your creative counterpart.",
  },
  {
    title: "Portfolio Showcases",
    description:
      "Present your work in beautifully curated project pages. Tag your disciplines, link collaborators, and let your portfolio speak to the community and potential clients.",
  },
  {
    title: "Collab Sprints",
    description:
      "Join time-boxed collaborative projects where creatives from different disciplines come together to build something new in 2-4 weeks. Think hackathons, but for design, film, and brand work.",
  },
  {
    title: "Creative Retreats",
    description:
      "In-person and virtual retreats designed to spark new ideas, build relationships, and recharge your creative energy. A space to pause, reset, and rethink your practice.",
  },
  {
    title: "Community {"&"} Events",
    description:
      "From fireside chats and skill-shares to launch parties and critique sessions — our events calendar is packed with ways to connect, learn, and grow alongside fellow creatives.",
  },
]

export function ServicesSection() {
  return (
    <section className="py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          <div>
            <p className="text-sm font-medium tracking-widest uppercase text-primary mb-3">
              What We Offer
            </p>
            <h2 className="text-3xl md:text-4xl font-serif italic text-foreground mb-6 text-balance">
              Built for Creatives, by Creatives.
            </h2>
            <p className="text-muted-foreground leading-relaxed text-pretty">
              Because when life and work move in sync, the best ideas don{"'"}t just
              happen, they flow. That{"'"}s why we built The Collectiv — a new way to
              pause, connect, and spark the thinking that fuels not just careers, but
              whole ways of being.
            </p>
          </div>

          <Accordion type="single" collapsible className="w-full">
            {services.map((service, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left text-base font-medium hover:text-primary">
                  {service.title}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">
                  {service.description}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  )
}
