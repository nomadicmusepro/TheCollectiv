"use client"

import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { MapPin } from "lucide-react"

const creatives = [
  {
    name: "Amara Okafor",
    role: "Brand Designer & Strategist",
    location: "Lagos, Nigeria",
    avatar: "/images/avatar-1.jpg",
    skills: ["Branding", "Strategy", "Visual Identity"],
    projects: 24,
    available: true,
  },
  {
    name: "Priya Nair",
    role: "Interior & Spatial Designer",
    location: "Mumbai, India",
    avatar: "/images/avatar-2.jpg",
    skills: ["Interior Design", "Architecture", "Styling"],
    projects: 31,
    available: false,
  },
  {
    name: "Valentina Reyes",
    role: "Filmmaker & Director",
    location: "Mexico City, Mexico",
    avatar: "/images/avatar-3.jpg",
    skills: ["Film", "Documentary", "Directing"],
    projects: 18,
    available: true,
  },
]

export function CreativesSection() {
  return (
    <section id="creatives" className="py-20 md:py-28 bg-secondary/50">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-sm font-medium tracking-widest uppercase text-primary mb-3">
            Meet the Community
          </p>
          <h2 className="text-3xl md:text-4xl font-serif italic text-foreground mb-4 text-balance">
            Creatives Who Inspire
          </h2>
          <p className="text-muted-foreground leading-relaxed text-pretty">
            From brand designers and filmmakers to architects and illustrators — our
            community is rich with talent ready to collaborate.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {creatives.map((creative) => (
            <article
              key={creative.name}
              className="bg-card border border-border rounded-lg p-6 hover:shadow-lg transition-shadow duration-300 cursor-pointer group"
            >
              <div className="flex items-start gap-4 mb-5">
                <Image
                  src={creative.avatar}
                  alt={creative.name}
                  width={56}
                  height={56}
                  className="rounded-full object-cover h-14 w-14"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-foreground truncate group-hover:text-primary transition-colors">
                      {creative.name}
                    </h3>
                    {creative.available && (
                      <span className="flex-shrink-0 h-2.5 w-2.5 rounded-full bg-primary" aria-label="Available for collaboration" />
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{creative.role}</p>
                  <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                    <MapPin className="h-3 w-3" />
                    {creative.location}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5 mb-5">
                {creative.skills.map((skill) => (
                  <Badge key={skill} variant="secondary" className="text-xs font-normal">
                    {skill}
                  </Badge>
                ))}
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-border">
                <span className="text-sm text-muted-foreground">
                  <span className="font-semibold text-foreground">{creative.projects}</span> projects
                </span>
                {creative.available ? (
                  <span className="text-xs font-medium text-primary">
                    Open to collaborate
                  </span>
                ) : (
                  <span className="text-xs font-medium text-muted-foreground">
                    Currently busy
                  </span>
                )}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
