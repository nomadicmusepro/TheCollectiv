"use client"

import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative pt-24 pb-16 md:pt-32 md:pb-24 overflow-hidden">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="flex flex-col gap-8">
            <div className="flex flex-col gap-6">
              <p className="text-sm font-medium tracking-widest uppercase text-primary">
                Where Creatives Connect
              </p>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif italic leading-tight text-balance text-foreground">
                Exclusively for Creatives, Filmmakers {"&"} Artists.
              </h1>
              <p className="text-lg leading-relaxed text-muted-foreground max-w-xl text-pretty">
                The Collectiv is a creative hub where entrepreneurs come to define who they are,
                sharpen their vision, and carve out what{"'"}s next. We help creatives find
                their voice through collaboration and community.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="gap-2 text-base">
                Explore Creatives
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="lg" className="text-base">
                Share Your Work
              </Button>
            </div>

            <div className="flex items-center gap-6 pt-4">
              <div className="flex -space-x-3">
                {[1, 2, 3].map((i) => (
                  <Image
                    key={i}
                    src={`/images/avatar-${i}.jpg`}
                    alt=""
                    width={40}
                    height={40}
                    className="rounded-full border-2 border-background object-cover h-10 w-10"
                  />
                ))}
              </div>
              <p className="text-sm text-muted-foreground">
                <span className="font-semibold text-foreground">2,400+</span> creatives
                already collaborating
              </p>
            </div>
          </div>

          <div className="relative">
            <div className="relative aspect-[4/5] rounded-lg overflow-hidden">
              <Image
                src="/images/hero-collage.jpg"
                alt="Creative entrepreneurs collaborating in a vibrant workspace"
                fill
                className="object-cover"
                priority
              />
            </div>
            <div className="absolute -bottom-4 -left-4 bg-card border border-border rounded-lg p-4 shadow-lg max-w-[220px]">
              <p className="text-xs font-medium text-primary uppercase tracking-wider">Trending</p>
              <p className="text-sm font-semibold text-card-foreground mt-1">Brand Identity Design</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                48 new projects this week
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
