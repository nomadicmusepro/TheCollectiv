"use client"

import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function Footer() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto max-w-7xl px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-12">
          <div>
            <h3 className="text-lg font-serif italic text-foreground mb-4">
              The Collectiv Newsletter
            </h3>
            <form
              onSubmit={(e) => e.preventDefault()}
              className="flex gap-2"
            >
              <Input placeholder="Enter email" type="email" className="flex-1" />
              <Button type="submit" size="sm">
                Submit
              </Button>
            </form>
          </div>

          <div>
            <h4 className="text-xs font-medium tracking-widest uppercase text-muted-foreground mb-4">
              Platform
            </h4>
            <nav className="flex flex-col gap-2.5" aria-label="Platform links">
              <Link href="#" className="text-sm text-foreground hover:text-primary transition-colors">Calendar</Link>
              <Link href="#" className="text-sm text-foreground hover:text-primary transition-colors">FAQs</Link>
              <Link href="#" className="text-sm text-foreground hover:text-primary transition-colors">Privacy</Link>
            </nav>
          </div>

          <div>
            <h4 className="text-xs font-medium tracking-widest uppercase text-muted-foreground mb-4">
              Social
            </h4>
            <nav className="flex flex-col gap-2.5" aria-label="Social links">
              <Link href="#" className="text-sm text-foreground hover:text-primary transition-colors">Instagram</Link>
              <Link href="#" className="text-sm text-foreground hover:text-primary transition-colors">LinkedIn</Link>
              <Link href="#" className="text-sm text-foreground hover:text-primary transition-colors">Bluesky</Link>
            </nav>
          </div>
        </div>
      </div>

      <div className="border-t border-border">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 py-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            2026 All Rights Reserved.
          </p>
          <p className="text-7xl md:text-9xl font-serif italic text-primary/10 select-none leading-none">
            The Collectiv
          </p>
          <p className="text-xs text-muted-foreground text-right">
            Exclusively for Creatives, Filmmakers {"&"} Artists.
          </p>
        </div>
      </div>
    </footer>
  )
}
