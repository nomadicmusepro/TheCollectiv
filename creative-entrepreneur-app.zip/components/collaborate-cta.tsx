"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Send } from "lucide-react"
import { useState } from "react"

export function CollaborateCta() {
  const [submitted, setSubmitted] = useState(false)

  return (
    <section id="collaborate" className="py-20 md:py-28 bg-secondary/50">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          <div id="contact">
            <p className="text-xs font-medium tracking-widest uppercase text-primary mb-4">
              Contact
            </p>
            <h2 className="text-3xl md:text-4xl font-serif italic text-foreground mb-6 text-balance">
              Ask us anything.
            </h2>
            <p className="text-muted-foreground leading-relaxed max-w-md text-pretty">
              Are you a creative entrepreneur looking to collaborate? A brand seeking
              fresh creative talent? A strategist, a coach, or simply inspired by what
              we{"'"}re building? Let{"'"}s connect.
            </p>
            <Button className="mt-6 gap-2" variant="outline">
              Get in Touch
              <Send className="h-4 w-4" />
            </Button>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Ready to start collaborating?
            </h3>
            <p className="text-sm text-muted-foreground mb-6">
              {"Let's start planning."}
            </p>

            {submitted ? (
              <div className="bg-primary/10 border border-primary/20 rounded-lg p-8 text-center">
                <p className="text-lg font-serif italic text-primary mb-2">
                  Thanks for reaching out!
                </p>
                <p className="text-sm text-muted-foreground">
                  {"We'll get back to you within 24 hours."}
                </p>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  setSubmitted(true)
                }}
                className="flex flex-col gap-4"
              >
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="first-name" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      First Name
                    </label>
                    <Input id="first-name" required placeholder="Your first name" />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="last-name" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      Last Name
                    </label>
                    <Input id="last-name" required placeholder="Your last name" />
                  </div>
                </div>
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="email" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Email
                  </label>
                  <Input id="email" type="email" required placeholder="you@example.com" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="organization" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      Organization
                    </label>
                    <Input id="organization" placeholder="Your studio or company" />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="role" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      Role
                    </label>
                    <Input id="role" placeholder="Your creative discipline" />
                  </div>
                </div>
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="message" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Message
                  </label>
                  <Textarea id="message" required placeholder="Tell us about your project or idea..." rows={4} />
                </div>
                <Button type="submit" className="self-center mt-2">
                  Submit
                </Button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
